import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

dataset = pd.read_json('practice_dataset.json', lines = True)
news_description = dataset["short_description"][0:200]
print(news_description.index)


model = SentenceTransformer('distilbert-base-nli-stsb-mean-tokens')
sentence_embeddings_bert = model.encode(news_description.values)

g = input("Enter short description of article you are looking for: ")
query_embedded = model.encode(g)

def find_similar(vector_query, vector_total_set, k=1):
    similarity_matrix = cosine_similarity(vector_query, vector_total_set)
    np.fill_diagonal(similarity_matrix, 0)
    similarities = similarity_matrix[0]
    if k == 1:
        return [np.argmax(similarities)]
    elif k is not None:
        return np.flip(similarities.argsort()[-k:][::1])

similar_indexes = find_similar(query_embedded,sentence_embeddings_bert , 5)
print("5 most similar descriptions using Sentence-Bert")
for index in similar_indexes:
    print(news_description[index])




